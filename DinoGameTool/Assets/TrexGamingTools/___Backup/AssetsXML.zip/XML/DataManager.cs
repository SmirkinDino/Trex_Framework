﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System;
using System.Reflection;

namespace Dino_Core.AssetsUtils
{
    /// <summary>
    /// 
    /// SmirkinDino 2017.04.10
    /// this is the manager of entity data list
    /// 
    /// </summary>
    public class DataManager : MonoSingleton<DataManager>
    {
        #region var

        /// <summary>
        /// attrs map
        /// </summary>
        private Dictionary<string, Dino_Core.NodeStruct> m_DataMapping;

        /// <summary>
        /// Adapter list
        /// </summary>
        private Dictionary<Type, iAdaptType> m_AdaptableTable = new Dictionary<Type, iAdaptType>() {
            { typeof(float), new AdaptFloat()},
            { typeof(int), new AdaptInt()},
            { typeof(bool), new AdaptBool()},
            { typeof(string), new AdaptString()},
            { typeof(float[]), new AdaptArray()},
            { typeof(int[]), new AdaptArray()},
            { typeof(string[]), new AdaptArray()},
            { typeof(Enum), new AdaptEnum()},
            { typeof(Vector2), new AdaptVector()},
            { typeof(Vector3), new AdaptVector()},
            { typeof(Vector4), new AdaptVector()},
        };

        /// <summary>
        /// read list
        /// </summary>
        private List<CoreClass> m_MapingList;

        public bool EnableAsyncLoad { get; set; }

        /// <summary>
        /// load finish?
        /// </summary>
        private bool m_IsLoadFinish = false;
        public bool IsAsyncing
        {
            get
            {
                return m_IsLoadFinish;
            }
            set
            {
                // ..
            }
        }
        private float m_Progress = 0;
        public float Progress
        {
            get { return this.m_Progress; }
            set
            {
                m_Progress = Mathf.Clamp(value, 0.0f, 100.0f);
            }
        }





        /// <summary>
        /// To save CG
        /// </summary>
        private Dino_Core.NodeStruct    _handledNode;
        private FileInfo[]              _handledFiles;
        private DirectoryInfo           _handledDir;
        private PropertyInfo[]          _handledProps;
        private iAdaptType              _handledAdapter;
        private MethodInfo              _handledMethod;
        private List<NodeStruct>        _handledAttrs;

        #endregion



        /// <summary>
        /// init and load and also store data
        /// </summary>
        public void InitAndLoad()
        {
            if (m_DataMapping == null) m_DataMapping = new Dictionary<string, NodeStruct>();
            if (m_MapingList == null) m_MapingList = new List<CoreClass>();
            m_MapingList.Clear();

            m_Progress = 0;

            LoadFilesAndSave(string.Format("{0}{1}{2}", Application.dataPath , "/StreamingAssets" ,"/Xml/"));

            if (EnableAsyncLoad) StartCoroutine("_excuteAsyncLoad");
            else LoadAll();
        }

        /// <summary>
        /// add class to read list
        /// </summary>
        /// <param name="_map"></param>
        public void AddMapToLoadlist(CoreClass _map)
        {
            if (m_MapingList.Contains(_map))
            {
                return;
            }
            m_MapingList.Add(_map);
        }

        /// <summary>
        /// remove class from read list
        /// </summary>
        /// <param name="_map"></param>
        public void RemoveMapFromLoadlist(CoreClass _map)
        {
            if (m_MapingList.Contains(_map))
            {
                m_MapingList.Remove(_map);
            }
        }

        /// <summary>
        /// load given class attrs list
        /// </summary>
        /// <param name="_map"></param>
        public void Load(CoreClass _map)
        {
            try
            {
                NodeStruct _data = XmlHandler.ReadNodesFromFile(_map.Path, "Root");
                m_DataMapping.Add(_map.ClassKey, _data);
            }
            catch (Exception)
            {
#if DINO_DEBUG
                this.DLog(string.Format("{0} file type wrong", _map.ClassKey));
#endif
            }
        }

        /// <summary>
        /// get given all tags y given class name
        /// </summary>
        /// <param name="_className">class name</param>
        /// <returns>tags</returns>
        public List<string> GetIDByClassname(string _className)
        {
            _handledNode = m_DataMapping.GetEntity(_className);

            if (_handledNode == null)
            {
                return null;
            }

            List<string> _subTypes = new List<string>();

            for (int i = 0; i < _handledNode.getChildren().Count; i++)
            {
                _subTypes.Add(_handledNode.getChildren()[i].getName());
            }

            return _subTypes;
        }

        /// <summary>
        /// init a class
        /// </summary>
        /// <param name="_className">class name ,file name as well</param>
        /// <param name="_ID">attrs tag</param>
        /// <param name="_obj">object</param>
        public void InitBean(string _className, string _ID, System.Object _obj)
        {
            try
            {
#if DINO_DEBUG
                //if (!m_IsLoadFinish) this.LogEditorOnly(string.Format("dataManager did not finish loading, progress: {0} / 100", m_Progress));
#endif
                _handledNode = m_DataMapping.GetEntity(_className).getChild(_ID);
                if (_handledNode == null)
                {
#if DINO_DEBUG
                    this.DLog(string.Format("{0} {1} did not found", _className, _ID));
#endif
                }
                InitMapping(_obj, _handledNode);
            }
            catch (Exception)
            {
#if DINO_DEBUG
                this.DLog(string.Format("{0} {1} {2} init failed", _className, _ID, _obj));
#endif
            }
        }

        /// <summary>
        /// Add adapter
        /// </summary>
        /// <param name="_type"></param>
        /// <param name="_func"></param>
        public void AddAdaptableType(Type _type, iAdaptType _func)
        {
            m_AdaptableTable.AddEntity(_type, _func);
        }

        private void LoadAll()
        {
            m_DataMapping.Clear();

            for (int i = 0; i < m_MapingList.Count; i++)
            {
                Load(m_MapingList[i]);
            }

            m_Progress = 100;
        }

        private IEnumerator _excuteAsyncLoad()
        {
            m_DataMapping.Clear();
            m_Progress = 0;
            m_IsLoadFinish = false;

            int _currentCount = 0;

            for (int i = 0;i < m_MapingList.Count; i++)
            {
                Load(m_MapingList[i]);

                Progress = _currentCount / m_MapingList.Count;

                _currentCount++;
            }

            yield return null;
            m_IsLoadFinish = true;
            m_Progress = 100;
        }

        /// <summary>
        /// load all xml file under path
        /// </summary>
        /// <param name="_dicPath">path</param>
        private void LoadFilesAndSave(string _dicPath)
        {
            _handledFiles = null;

            // get all file under this dir
            if (Directory.Exists(_dicPath))
            {
                _handledDir = new DirectoryInfo(_dicPath);
                _handledFiles = _handledDir.GetFiles("*.xml", SearchOption.AllDirectories);
            }

            if (_handledFiles != null)
            {
#if DINO_DEBUG
                this.DLog(string.Format("find {0:D1} XMLs，adding to read list", _handledFiles.Length));
#endif
            }
            else
            {
                return;
            }

            for (int i = 0;i < _handledFiles.Length; i++ )
            {
                CoreClass _map = new CoreClass();
                _map.Path = _handledFiles[i].ToString();
                _map.ClassKey = _handledFiles[i].Name.Split('.')[0];
                AddMapToLoadlist(_map);
            }
        }

        /// <summary>
        /// init class
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="_path"></param>
        private void InitMapping(System.Object obj, string _path)
        {
            _handledNode = Dino_Core.XmlHandler.ReadNodesFromFile(_path, "Root");
            _excuteMapping(obj, _handledNode);
        }

        private void InitMapping(System.Object obj, Dino_Core.NodeStruct _data)
        {
            _excuteMapping(obj, _data);
        }

        /// <summary>
        /// adapt data
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="_data"></param>
        private void _excuteMapping(System.Object obj, Dino_Core.NodeStruct _data)
        {
            _handledProps = obj.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);

            for (int i = 0; i < _handledProps.Length; i++)
            {
                _handledMethod = _handledProps[i].GetSetMethod();
                _handledAttrs = _data.getChildren();

                for (int j = 0; j < _handledAttrs.Count; j++)
                {
                    if (!_handledProps[i].Name.Equals(_handledAttrs[j].getName())) continue;

                    if (_handledMethod != null)
                    {
                        System.Object value = null;

                        try
                        {
                            _handledAdapter = m_AdaptableTable.GetEntity(_handledProps[i].PropertyType.IsEnum ? typeof(Enum) : _handledProps[i].PropertyType);
                            _handledAdapter.Adapt(out value, _handledAttrs[j].getValue(), _handledProps[i].PropertyType);
                            _handledMethod.Invoke(obj, new object[] { value });
                        }
                        catch (Exception)
                        {
#if DINO_DEBUG
                            this.DLog(string.Format("adapt failed - attr {0} {1}", bn.getName(), bn.getValue()));
#endif
                        }
                        break;
                    }
                    else
                    {
                        break;
                    }
                }
            }
        }


    }









    /// <summary>
    /// to store class path and key
    /// </summary>
    public class CoreClass
    {
        public string Path;
        public string ClassKey;
    }
}

