﻿using UnityEngine;
using System.Collections;
using System;

namespace Dino_Core.AssetsUtils
{
    public interface iAdaptType
    {
        void Adapt(out object value, string data, Type t);
    }

    public class AdaptString : iAdaptType
    {
        public void Adapt(out object value, string data, Type t)
        {
            value = data;
        }
    }

    public class AdaptInt : iAdaptType
    {
        public void Adapt(out object value, string data, Type t)
        {
            value = int.Parse(data);
        }
    }

    public class AdaptFloat : iAdaptType
    {
        public void Adapt(out object value, string data, Type t)
        {
            value = float.Parse(data);
        }
    }

    public class AdaptBool : iAdaptType
    {
        public void Adapt(out object value, string data, Type t)
        {
            value = bool.Parse(data);
        }
    }

    public class AdaptArray : iAdaptType
    {
        public void Adapt(out object value, string data, Type t)
        {
            value = null;

            if (t == typeof(int[]))
            {
                value = Dino_Core.StrExtends.SwitchToIntArray(data, '|');
            }
            else if(t == typeof(float[]))
            {
                value = Dino_Core.StrExtends.SwitchToFloatArray(data, '|');
            }
            if (t == typeof(string[]))
            {
                value = data.Split('|');
            }
        }
    }

    public class AdaptVector : iAdaptType
    {
        public void Adapt(out object value, string data, Type t)
        {
            if (t == typeof(Vector2))
            {
                value = Dino_Core.StrExtends.SwitchToVector2(data);
            }
            else if (t == typeof(Vector3))
            {
                value = Dino_Core.StrExtends.SwitchToVector3(data);
            }
            if (t == typeof(Vector4))
            {
                value = Dino_Core.StrExtends.SwitchToVector4(data);
            }
            value = null;
        }
    }

    public class AdaptEnum : iAdaptType
    {
        public void Adapt(out object value, string data, Type t)
        {
            value = Enum.Parse(t, data);
        }
    }


}


