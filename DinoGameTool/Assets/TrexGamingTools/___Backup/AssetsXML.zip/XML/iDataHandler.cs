﻿public interface iDataHandler
{

    /// <summary>
    /// 数据适配接口
    /// </summary>
    /// <param name="_data"></param>
    void Adapt(object _data = null);

    /// <summary>
    /// 数据初始化接口
    /// </summary>
    /// <param name="_objs"></param>
    void Init(params object[] _objs);
}



